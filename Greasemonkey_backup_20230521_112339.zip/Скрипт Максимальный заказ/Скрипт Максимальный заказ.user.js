// ==UserScript==
// @name     Скрипт Максимальный заказ
// @version  1
// @grant    none
// ==/UserScript==

function getAllNextSiblings(element) {
    var out = [];
    while(element.nextSibling) {
        out.push(element = element.nextSibling);
    }

    return out;
}

function getAllPreviousSiblings(element) {
    var out = [];
    while(element.previousSibling) {
        out.push(element = element.previousSibling);
    }

    return out;
}

function getAllSiblings(element, include) {
    var out = getAllNextSiblings(element);
    out.concat(getAllPreviousSiblings(element));
    if(include)
        out.push(element);

    return out;
}

function maxOrder(){
  alert("max order")
	e = document.querySelectorAll('.oPrice');
  maxPrice = 0;
  maxElement = "";
  for(var i=0; i<e.length; i++ ){
  	
    t = getAllPreviousSiblings(e[i])
    for(var j=0; j<t.length; j++){
    	if (t[j].textContent <> "РАБОТА"){
      	continue;
      } 
      var price = Number(e.textContent);
      if (price > maxPrice){
      	maxPrice = price;
        maxElement = t[j];
      }
  	}
    
  }
  
  alert(maxPrice)
}



window.onload = function() {
	  maxOrder();
};
