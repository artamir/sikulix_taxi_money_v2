// ==UserScript==
// @name     Скрипт БезИмени 435254
// @version  1
// @grant    none
// ==/UserScript==

document.getElementById(#submit_service_2).scrollIntoView();
unsafeWindow.console.log("#submit_service_2.scrollIntoView()");