// ==UserScript==
// @name     Скрипт БезИмени 662135
// @version  1
// @grant    none
// ==/UserScript==
//alert(1);

minPercentHaltura = 100
minElementHaltura = ""  
e = document.querySelectorAll('div[data-title*="Халтура"]');
for (var i = 0; i < e.length; i++) {
	t = e[i].querySelector("span")
  var price = parseFloat(e[i].textContent);
  if (price < minPercentHaltura) {
  	minPercentHaltura = price;
    minElementHaltura = t;//e[i];
  }
  
}
alert(minPercentHaltura);
minElement = minElementHaltura;
color = "blue"
if (minElement != "") {
		if (minElement.textContent.indexOf("Халтура") == -1) {
			minElement.textContent = "Халтура"
			
      el = minElement;
			el.style.setProperty("outline", "5px solid " + color, "important");
      alert(el.closest(".mining-map.disabled"))
      if(el.closest(".mining-map.disabled")!=null){	
        el.style.setProperty("text-decoration", "line-through", "important");
    	}
      
      
      el = minElement.parentElement;
      el.style.setProperty("backgroung","white","important");
      el.style.setProperty("opacity","1","important");
      
      el = minElement.parentElement.parentElement;
      el.style.setProperty("width", "80px", "important");
      el.style.setProperty("height", "50px", "important");
      el.style.setProperty("opacity","1","important");
      
      
		}
	}
