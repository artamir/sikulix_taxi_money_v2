// ==UserScript==
// @name     Скрипт БезИмени 930294
// @version  1
// @grant    none
// ==/UserScript==
function displayNone() {
    //e = document.querySelectorAll('.oImage,.oTime,.oPower,.oAddress,.party-order-container,.level-block,.d-block,.spo-block');
    e = document.querySelectorAll('.d-block,.spo-block');
    for (var i = 0; i < e.length; i++) {
        e[i].style.display = 'none';
    }

    e = document.querySelectorAll('.oInner');
    for (var i = 0; i < e.length; i++) {
        //e[i].style.width = '332px';
        //e[i].style.height = '141.133px';
    }
}

function orderPriceFont(){
  fn = "orderPriceFont"
  //alert(fn)
	e = document.querySelectorAll('[data-control="price"]');
  for (var i = 0; i < e.length; i++) {
  	//alert(e[i])
    if (e[i].textContent.indexOf("Д:") == -1) {
    	e[i].textContent = "Д: "+e[i].textContent
    	e[i].style.setProperty('font-family','OCR-B',"important");
    	e[i].style.setProperty('font-weight','bold',"important");
    	e[i].style.setProperty('font-size','large',"important");
    }  
	}
}

function orderTimeFont(){
  fn = "orderTimeFont"
  //alert(fn)
	e = document.querySelectorAll('.oTime');
  for (var i = 0; i < e.length; i++) {
  	//alert(e[i])
    if (e[i].textContent.indexOf("В:") == -1) {
    	e[i].textContent = "В: "+e[i].textContent
    	e[i].style.setProperty('font-family','OCR-B',"important");
    	e[i].style.setProperty('font-weight','bold',"important");
    	e[i].style.setProperty('font-size','large',"important");
    }  
	}
}


function getAllNextSiblings(element) {
    var out = [];
    while (element.nextSibling) {
        out.push(element = element.nextSibling);
    }

    return out;
}

function getAllPreviousSiblings(element) {
    var out = [];
    while (element.previousSibling) {
        out.push(element = element.previousSibling);
    }

    return out;
}

function getAllSiblings(element, include) {
    var out = getAllNextSiblings(element);
    out.concat(getAllPreviousSiblings(element));
    if (include)
        out.push(element);

    return out;
}

function maxOrder(){
    //alert("max order")
    e = document.querySelectorAll('.oPrice');
    maxBonusPrice = 0.00;
    maxBonusElement = "";
    maxHalturaPrice = 0.00;
    maxHalturaElement = "";
    maxRabotaPrice = 0.00;
    maxRabotaElement = "";
    for (var i = 0; i < e.length; i++) {
        t = getAllNextSiblings(e[i].parentElement);
        for (var j = 0; j < t.length; j++) {
            if (t[j].textContent.indexOf("Бонус") > -1) {
                var price = parseFloat(e[i].textContent);
                //alert(price);
                if (price > maxBonusPrice) {
                    maxBonusPrice = price;
                    maxBonusElement = t[j];
                }
            }
            if (t[j].textContent.indexOf("Халтура") > -1) {
                var price = parseFloat(e[i].textContent);
                //alert(price);
                if (price > maxHalturaPrice) {
                    maxHalturaPrice = price;
                    maxHalturaElement = t[j];
                }
            }
            if (t[j].textContent.indexOf("Работа") > -1) {
                var price = parseFloat(e[i].textContent);
              	if (isNaN(price)){
                	continue;
                }
                //alert(price);
                if (price > maxRabotaPrice) {
                    maxRabotaPrice = price;
                    maxRabotaElement = t[j];
                }
            }
        }

    }

    maxElement = maxBonusElement;
    color = "red"
	if (maxElement != "") {
		if (maxBonusElement.textContent.indexOf("макс") == -1) {
			maxElement.textContent = maxElement.textContent + "-макс\nmax"
				el = maxElement.parentElement.parentElement.parentElement;
			el.style.setProperty("outline", "1px solid " + color, "important")
		}
	}

    maxElement = maxHalturaElement;
    color = "blue"
	if (maxElement != "") {
		if (maxElement.textContent.indexOf("макс") == -1) {
			maxElement.textContent = maxElement.textContent + "-макс\nmax"
				el = maxElement.parentElement.parentElement.parentElement;
			el.style.setProperty("outline", "1px solid " + color, "important")
		}
	}

    maxElement = maxRabotaElement;
    color = "green"
	if (maxElement != "") {
		if (maxElement.textContent.indexOf("макс") == -1) {
			maxElement.textContent = maxElement.textContent + "-макс\nmax"
				el = maxElement.parentElement.parentElement.parentElement;
			el.style.setProperty("outline", "1px solid " + color, "important")
		}
	}
        //alert(maxPrice);
}

function minRudaPercent(){
	minPercentHaltura = 100
  minElementHaltura = ""  
  e = document.querySelectorAll('div[data-title*="Халтура"]');
  for (var i = 0; i < e.length; i++) {
    t = e[i].querySelector("span")
    var price = parseFloat(e[i].textContent);
    if (price < minPercentHaltura) {
      minPercentHaltura = price;
      minElementHaltura = t;//e[i];
    }

  }
  //alert(minPercentHaltura);
  minElement = minElementHaltura;
  color = "blue"
  if (minElement != "") {
    
			textHaltura = "Халтура |ORDER|";
    	if(minElement.closest(".mining-map.disabled")!=null){
      	textHaltura = " |Reload| ";
      }
    
      if (minElement.textContent.indexOf(textHaltura) == -1) {
        minElement.textContent = minElement.textContent + textHaltura;

        el = minElement;
        el.style.setProperty("outline", "5px solid " + color, "important");
        el.style.setProperty("background-image","none","important");
        el.style.setProperty("background-color","aqua","important");
        el.style.setProperty("width","auto","important");
        //alert(el.closest(".mining-map.disabled"))
        if(el.closest(".mining-map.disabled")!=null){	
          el.style.setProperty("text-decoration", "line-through", "important");
        }


        el = minElement.parentElement;
        el.style.setProperty("backgroung","white","important");
        el.style.setProperty("opacity","1","important");
        el.style.setProperty("width","auto","important");

        el = minElement.parentElement.parentElement;
        el.style.setProperty("width", "80px", "important");
        el.style.setProperty("height", "50px", "important");
        el.style.setProperty("opacity","1","important");
        el.style.setProperty("z-index","100","important");


      }
  }
  
  setTimeout(minRudaPercent, 100)

}

function setBtnText(){
  //alert('setBtnText')
  
  var e = document.querySelector('div.mb-*:nth-child(1) > button:nth-child(1)');
  //alert(e);
  //alert(1);
	if(e!=null){ 
  	if(e.closest('style*="display: none"')==null){
  //  	alert(e)
		}
  }  
  //alert(3)
  setTimeout(setBtnText, 1000)
}

displayNone();
setTimeout(minRudaPercent, 1000)
//setTimeout(setBtnText, 1000)
//alert(2);
document.addEventListener("DOMAttrModified", function () {
    //  alert(3);
    displayNone();
    maxOrder();
    orderPriceFont();
  	orderTimeFont();
  	minRudaPercent();
});

window.onload = function () {
    displayNone();
    maxOrder();
    orderPriceFont();
  	orderTimeFont();
  	minRudaPercent();
};
